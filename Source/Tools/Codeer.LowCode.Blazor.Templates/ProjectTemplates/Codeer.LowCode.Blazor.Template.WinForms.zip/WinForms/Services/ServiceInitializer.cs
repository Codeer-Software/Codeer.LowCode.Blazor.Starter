using Codeer.LowCode.Blazor.RequestInterfaces;
using Sotsera.Blazor.Toaster.Core.Models;
using Codeer.LowCode.Blazor.Components.AppParts.Loading;
using Microsoft.Extensions.DependencyInjection;
using System.Globalization;
using Codeer.LowCode.Blazor.Extras.Fields;
using Codeer.LowCode.Blazor.Extras.Services;
using $safeprojectname$.Extras;

namespace $safeprojectname$.Services
{
    public static class ServiceInitializer
    {
        public static void AddSharedServices(this IServiceCollection services)
        {
            //デスクトップはサーバーを介さずローカルで処理する (Excel.ConvertPdf / MailTransport.Handler / AITextAnalyzerField のフック)
            Codeer.LowCode.Blazor.Extras.Api.ExtrasTransport.EndPoint = string.Empty;
            services.AddScoped<IAppInfoService, AppInfoService>();
            services.AddScoped<IModuleDataService, ModuleDataService>();
            services.AddScoped<IUIService, UIService>();
            services.AddScoped<Codeer.LowCode.Blazor.RequestInterfaces.Services>();
            services.AddScoped<ILogger, Logger>();
            services.AddSingleton<LoadingService>();
            services.AddToaster(config =>
            {
                config.PositionClass = Defaults.Classes.Position.BottomRight;
                config.MaximumOpacity = 100;
                config.VisibleStateDuration = 1000 * 5;
                config.ShowTransitionDuration = 10;
                config.HideTransitionDuration = 500;
            });
            services.AddScoped<IToastService, ToastService>();
            services.AddScoped<IHttpService, HttpService>();
            services.AddScoped<AITextAnalyze>();
            AITextAnalyzerField.FileToModuleDataCoreAsync = (field, fileName, content)
                => field.Services.Provider.GetRequiredService<AITextAnalyze>()
                    .FileToModuleDataAsync(field.Module.Design.Name, field.Design.Name, fileName, content);
            AITextAnalyzerField.TextToModuleDataCoreAsync = (field, text)
                => field.Services.Provider.GetRequiredService<AITextAnalyze>()
                    .TextToModuleDataAsync(field.Module.Design.Name, field.Design.Name, text);

            services.AddScoped<INavigationService, NavigationService>();
            //大きな添付 (動画など) のアップロードが既定の 100 秒で切れないようにする
            services.AddScoped(sp => new HttpClient { Timeout = TimeSpan.FromMinutes(30) });

            var cultureName = CultureInfo.CurrentCulture.Name;
            if (cultureName == "ja") cultureName = "ja-JP";
            var cultureInfo = new CultureInfo(cultureName);
            CultureInfo.DefaultThreadCurrentCulture = cultureInfo;
            CultureInfo.DefaultThreadCurrentUICulture = cultureInfo;
        }
    }
}

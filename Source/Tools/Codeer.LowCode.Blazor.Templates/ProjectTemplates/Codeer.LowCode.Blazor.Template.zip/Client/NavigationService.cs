using Microsoft.AspNetCore.Components;
using $safeprojectname$.Shared.Services;

namespace $safeprojectname$
{
    public class NavigationService : NavigationServiceBase
    {
        public NavigationService(NavigationManager nav) : base(nav) { }
        public override bool CanLogout => false;
        public override async Task Logout() => await Task.CompletedTask;
    }
}

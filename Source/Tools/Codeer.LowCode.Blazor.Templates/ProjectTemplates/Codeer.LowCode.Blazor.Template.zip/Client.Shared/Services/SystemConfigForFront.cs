namespace $safeprojectname$.Services
{
    public class SystemConfigForFront
    {
        public bool CanScriptDebug { get; set; }
        public bool UseHotReload { get; set; }
    }
}

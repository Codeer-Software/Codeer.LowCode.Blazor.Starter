using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication.Cookies;
using $safeprojectname$.Services;
using Codeer.LowCode.Blazor.DbAccess;
using Codeer.LowCode.Blazor.Extras.Server.AuditLog;
using Codeer.LowCode.Blazor.Extras.Server.Auth;

namespace $safeprojectname$
{
    public static class CookieAuthentication
    {
        public static void UseCookieAuthentication(this WebApplicationBuilder builder)
        {
            //ログイン途中の一時データ (外部 IdP の MAUI 向け使い捨てチケット、メール認証コード) の置き場。
            //これはプロセス内メモリなので単一インスタンス向け。App Service 等で複数インスタンスに広げるときは
            //AddStackExchangeRedisCache / AddDistributedSqlServerCache などの共有キャッシュに差し替える
            //(発行したインスタンスと検証するインスタンスが違うと失敗するため)。総当たり対策 (LoginLockout) の回数もここに置く。
            //共有キャッシュを複数のアプリで使うときは InstanceName でアプリごとに分ける (キーはユーザーの Id なので、分けないと別のアプリの同じ Id と混ざる)
            builder.Services.AddDistributedMemoryCache();

            builder.Services
                .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
                .AddCookie(options => {
                    options.Events.OnRedirectToLogin = context =>
                    {
                        context.Response.StatusCode = 401;
                        return Task.CompletedTask;
                    };
                    options.Events.OnRedirectToAccessDenied = context =>
                    {
                        context.Response.StatusCode = 403;
                        return Task.CompletedTask;
                    };
                })
                //外部 IdP (Entra ID / Google / AWS Cognito / OIDC)。並べるプロバイダは Services/ExternalLoginTable が組み立てる
                .AddExternalLogins(ExternalLoginTable.Create(), o => o.MobileCallbackUrl = SystemConfig.Instance.MobileLoginCallbackUrl);
            builder.Services.AddScoped<IExternalLoginUserResolver, ExternalLoginUserResolver>();

            //CSRF
            builder.Services.AddAntiforgery(options => {
                options.HeaderName = "X-ANTIFORGERY-TOKEN";
            });
        }

        public static void UseCookieAuthentication(this WebApplication app)
        {
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseAntiforgery();

            _ = CreateInitialUserAsync(app);
        }

        public static void AppendAntiforgeryTokenCookie(HttpContext ctx)
        {
            var anti = ctx.RequestServices.GetRequiredService<IAntiforgery>();
            var tokens = anti.GetAndStoreTokens(ctx);
            ctx.Response.Cookies.Append(
                "X-ANTIFORGERY-TOKEN",
                tokens.RequestToken ?? string.Empty,
                new CookieOptions
                {
                    HttpOnly = false,
                    Secure = true,
                    SameSite = SameSiteMode.Lax
                });
        }

        //ユーザーが 0 件なら admin / admin を作る (表・列はユーザーモジュールのデザインから。パスワードログインがある構成だけ)。
        static async Task CreateInitialUserAsync(WebApplication app)
        {
            await using var dbAccessor = new DbAccessor(SystemConfig.Instance.DataSources);
            var designData = DesignerService.GetDesignData();
            var accounts = LoginAccountStore.Create(designData, dbAccessor);
            if (accounts == null || !accounts.HasPassword || await accounts.AnyAsync()) return;
            var userId = await accounts.AddAsync("admin", "admin");
            try
            {
                await app.Services.GetRequiredService<AuditLogger>().WriteAsync(new AuditEvent
                {
                    Category = AuditCategory.System,
                    Action = "Account.InitialUserCreated",
                    Targets = { new AuditTarget { Module = designData.AppSettings.CurrentUserModuleDesignName, Id = userId, Operation = "Add" } },
                    Detail = "LoginName=admin",
                });
            }
            catch (AuditLogException)
            {
            }
        }
    }
}

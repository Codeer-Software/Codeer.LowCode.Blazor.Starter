using Codeer.LowCode.Blazor;
using Codeer.LowCode.Blazor.Aggregation;
using Codeer.LowCode.Blazor.DataIO;
using Codeer.LowCode.Blazor.Repository.Data;
using Codeer.LowCode.Blazor.Repository.Match;
using Codeer.LowCode.Blazor.RequestInterfaces;
using Codeer.LowCode.Blazor.Utils;
using Excel.Report.PDF;
using Codeer.LowCode.Blazor.DbAccess;
using Codeer.LowCode.Blazor.Extras.Server.FileManagement;
using $safeprojectname$.Extras;

namespace $safeprojectname$.Services
{
    public class ModuleDataService : IModuleDataService
    {
        ILogger _logger;

        public ModuleDataService(ILogger logger)
            => _logger = logger;

        public async Task<Paging<ModuleData>> GetListAsync(SearchCondition condition, int pageIndex, bool withLock)
            => await CheckoutException(async dataIO => await dataIO.GetListAsync(condition!, pageIndex), new());

        public async Task<List<AggregateResult>> AggregateAsync(List<AggregateCondition> conditions)
        {
            await using var dbAccess = new DbAccessor(SystemConfig.Instance.DataSources);
            var temporaryFileManager = new TemporaryFileManager(dbAccess, SystemConfig.Instance.TemporaryFileTableInfo, FileStorageTable.Storages);
            var dataIO = new CustomizedModuleDataIO(AppDesign.Store.GetDesignData(), new AuthenticationContext(), dbAccess, temporaryFileManager);
            return await dataIO.AggregateAsync(conditions);
        }

        public async Task<List<ModuleSubmitResult>?> SubmitAsync(List<ModuleSubmitData> data)
            => await CheckoutException(async dataIO => await dataIO.SubmitWithTransactionAsync(data), null);

        public async Task<Codeer.LowCode.Blazor.DataIO.FileInfo?> UploadFile(string moduleName, string fieldName, string fileName, StreamContent content)
            => await CheckoutException(async dataIO => {

                var moduleDataIO = dataIO;
                var info = await moduleDataIO.FileFieldDataIO.GetFileSaveInfoAsync(moduleName ?? string.Empty, fieldName ?? string.Empty);
                using (var stream = content.ReadAsStream())
                {
                    return await moduleDataIO.TemporaryFileManager.AddFileAsync(info, fileName, stream);
                }
            }, null);

        //レコードのコピー (CopyModule) の添付: 元の行の添付をダウンロードと同じ権限で読み、実体を複製した新しい一時ファイルにする
        public async Task<Codeer.LowCode.Blazor.DataIO.FileInfo?> CopyFile(string moduleName, string fieldName, string id)
            => await CheckoutException(async dataIO => await dataIO.FileFieldDataIO.CopyFileAsync(moduleName ?? string.Empty, id ?? string.Empty, fieldName ?? string.Empty), null);

        public async Task<MemoryStream?> DownloadFile(string moduleName, string fieldName, string id)
        {
            MemoryStream? mem = null;
            Exception? exp = null;
            var thread = new Thread(() =>
            {
                try
                {
                    using var dbAccess = new DbAccessor(SystemConfig.Instance.DataSources);
                    var temporaryFileManager = new TemporaryFileManager(dbAccess, SystemConfig.Instance.TemporaryFileTableInfo, FileStorageTable.Storages);
                    var moduleDataIO = new CustomizedModuleDataIO(AppDesign.Store.GetDesignData(), new AuthenticationContext(), dbAccess, temporaryFileManager);

                    var location = moduleDataIO.FileFieldDataIO.GetFileLocation(moduleName!, id!, fieldName!).Result;
                    moduleDataIO.DbAccess.ClearAsync().AsTask().Wait();
                    mem = StorageAccess.ReadFileAsync(FileStorageTable.Storages, location).Result;
                }
                catch (Exception e)
                {
                    exp = e;
                }
            });
            thread.Start();
            while (thread.IsAlive) DoEventsHelper.DoEvents();
            if (exp != null) await _logger.Error(exp.Message);
            return mem;
        }

        public async Task<MemoryStream?> DownloadTemporaryFile(string moduleName, string fieldName, Guid guid, string? fileName)
        {
            MemoryStream? mem = null;
            Exception? exp = null;
            var thread = new Thread(() =>
            {
                try
                {
                    using var dbAccess = new DbAccessor(SystemConfig.Instance.DataSources);
                    var temporaryFileManager = new TemporaryFileManager(dbAccess, SystemConfig.Instance.TemporaryFileTableInfo, FileStorageTable.Storages);
                    var moduleDataIO = new CustomizedModuleDataIO(AppDesign.Store.GetDesignData(), new AuthenticationContext(), dbAccess, temporaryFileManager);

                    var location = moduleDataIO.FileFieldDataIO.GetTemporaryFileLocation(moduleName, fieldName, guid, fileName).Result;
                    moduleDataIO.DbAccess.ClearAsync().AsTask().Wait();
                    mem = StorageAccess.ReadFileAsync(FileStorageTable.Storages, location).Result;
                }
                catch (Exception e)
                {
                    exp = e;
                }
            });
            thread.Start();
            while (thread.IsAlive) DoEventsHelper.DoEvents();
            if (exp != null) await _logger.Error(exp.Message);
            return mem;
        }

        public async Task<MemoryStream?> GetListFileAsync(SearchCondition condition)
           => await CheckoutException(async dataIO => ExcelUtils.CreateExcelBinary(await dataIO.GetTableTextsAsync(condition!), "data"), null);

        public async Task<List<ModuleSubmitResult>?> SubmitByFileAsync(string moduleName, StreamContent content)
            => await CheckoutException(async dataIO => {
                using (var stream = content.ReadAsStream())
                {
                    var texts = await ExcelUtils.ReadAllTextsFromExcelBinary(stream);
                    if (500 < texts.Count) throw LowCodeException.Create("Excel has a maximum of 500 rows");
                    return await dataIO.SubmitWithTransactionByTableTextsAsync(moduleName, texts);
                }
            }, null);

        async Task<T> CheckoutException<T>(Func<CustomizedModuleDataIO, Task<T>> f, T errResult)
        {
            await using var dbAccess = new DbAccessor(SystemConfig.Instance.DataSources);
            var temporaryFileManager = new TemporaryFileManager(dbAccess, SystemConfig.Instance.TemporaryFileTableInfo, FileStorageTable.Storages);
            var dataIO = new CustomizedModuleDataIO(AppDesign.Store.GetDesignData(), new AuthenticationContext(), dbAccess, temporaryFileManager);
            try
            {
                return await f(dataIO);
            }
            catch (Exception e)
            {
                await _logger.Error(e.Message);
                return errResult;
            }
        }
    }
}

using Codeer.LowCode.Blazor.DataIO;

namespace $safeprojectname$.Services
{
    public class AuthenticationContext : IAuthenticationContext
    {
        public async Task<string> GetCurrentUserIdAsync()
        {
            await Task.CompletedTask;
            return string.Empty;
        }
    }

}

using Microsoft.AspNetCore.Components;
using $ext_safeprojectname$.Client.Shared.Services;

namespace $safeprojectname$.Services
{
    public class NavigationService : NavigationServiceBase
    {
        public NavigationService(NavigationManager nav) : base(nav) { }
        public override bool CanLogout => false;
        public override async Task Logout() => await Task.CompletedTask;
    }
}

using Codeer.LowCode.Blazor.Aggregation;
using Codeer.LowCode.Blazor.DataIO;
using Codeer.LowCode.Blazor.Extras.Services;
using Codeer.LowCode.Blazor.Repository.Data;
using Codeer.LowCode.Blazor.Repository.Match;
using Codeer.LowCode.Blazor.RequestInterfaces;
using Codeer.LowCode.Blazor.Utils;
using MessagePack;

namespace $safeprojectname$.Services
{
    public class ModuleDataService : IModuleDataService
    {
        readonly IHttpService _http;

        public ModuleDataService(IHttpService http)
            => _http = http;

        public async Task<List<Paging<ModuleData>>> GetListAsync(List<GetListRequest> request)
            => await GetListAsync(_http, request);

        public static async Task<List<Paging<ModuleData>>> GetListAsync(IHttpService http, List<GetListRequest> request)
        {
            var result = await http.PostAsJsonReturnHttpResponseAsync($"/api/module_data/list", request);
            if (result == null) return new();
            using var memory = (MemoryStream)await result!.Content.ReadAsStreamAsync();
            var obj = MessagePackSerializer.Typeless.Deserialize(memory);
            return obj as List<Paging<ModuleData>> ?? new();
        }

        public async Task<List<AggregateResult>> AggregateAsync(List<AggregateCondition> conditions)
        {
            var result = await _http.PostAsJsonReturnHttpResponseAsync($"/api/module_data/aggregate", conditions);
            //失敗は空のリスト (理由は HttpService が通知する)
            if (result == null) return new();
            using var memory = (MemoryStream)await result.Content.ReadAsStreamAsync();
            return MessagePackSerializer.Typeless.Deserialize(memory) as List<AggregateResult>
                ?? new();
        }

        public async Task<List<ModuleSubmitResult>?> SubmitAsync(List<ModuleSubmitData> data)
            => await _http.PostAsJsonAsync<List<ModuleSubmitData>, List<ModuleSubmitResult>>($"/api/module_data", data);

        public async Task<Codeer.LowCode.Blazor.DataIO.FileInfo?> UploadFile(string moduleName, string fieldName, string fileName, StreamContent content)
            => await _http.PostContentAsJsonAsync<Codeer.LowCode.Blazor.DataIO.FileInfo>($"/api/module_data/upload?moduleName={moduleName}&fieldName={fieldName}&fileName={fileName}", content);

        public async Task<MemoryStream?> DownloadFile(string moduleName, string fieldName, string id)
        {
            var result = await _http.GetAsync($"/api/module_data/download?moduleName={moduleName}&fieldName={fieldName}&id={id}", false);
            if (result == null) return null;
            return (MemoryStream)await result.Content.ReadAsStreamAsync();
        }

        //レコードのコピー (CopyModule) の添付: サーバーで実体を複製した新しい一時ファイルを受け取る
        public async Task<Codeer.LowCode.Blazor.DataIO.FileInfo?> CopyFile(string moduleName, string fieldName, string id)
            => await _http.PostContentAsJsonAsync<Codeer.LowCode.Blazor.DataIO.FileInfo>($"/api/module_data/copy_file?moduleName={Uri.EscapeDataString(moduleName)}&fieldName={Uri.EscapeDataString(fieldName)}&id={Uri.EscapeDataString(id)}", null);

        //ブラウザが直接読む URL (FileField の動画再生とダウンロードのリンク)。<base href> 相対で返す。MAUI / WPF の WebView は要素の要求に認証が付かないので null
        public string? GetFileUrl(string moduleName, string fieldName, string id)
            => OperatingSystem.IsBrowser()
                ? $"api/module_data/download?moduleName={Uri.EscapeDataString(moduleName)}&fieldName={Uri.EscapeDataString(fieldName)}&id={Uri.EscapeDataString(id)}"
                : null;

        public async Task<MemoryStream?> DownloadTemporaryFile(string moduleName, string fieldName, Guid guid, string? fileName)
        {
            var result = await _http.GetAsync($"/api/module_data/download_temporary?moduleName={Uri.EscapeDataString(moduleName)}&fieldName={Uri.EscapeDataString(fieldName)}&guid={guid}&fileName={Uri.EscapeDataString(fileName ?? string.Empty)}", false);
            if (result == null) return null;
            return (MemoryStream)await result.Content.ReadAsStreamAsync();
        }

        public string? GetTemporaryFileUrl(string moduleName, string fieldName, Guid guid, string? fileName)
            => OperatingSystem.IsBrowser()
                ? $"api/module_data/download_temporary?moduleName={Uri.EscapeDataString(moduleName)}&fieldName={Uri.EscapeDataString(fieldName)}&guid={guid}&fileName={Uri.EscapeDataString(fileName ?? string.Empty)}"
                : null;

        public async Task<MemoryStream?> GetListFileAsync(SearchCondition condition)
        {
            var result = await _http.PostAsJsonReturnHttpResponseAsync($"/api/module_data/list_file", condition);
            if (result == null) return null;
            return (MemoryStream)await result.Content.ReadAsStreamAsync();
        }

        public async Task<List<ModuleSubmitResult>?> SubmitByFileAsync(string moduleName, StreamContent content)
            => await _http.PostContentAsJsonAsync<List<ModuleSubmitResult>>($"/api/module_data/submit_by_file?moduleName={moduleName}", content);
    }
}

using Codeer.LowCode.Blazor.RequestInterfaces;
using Sotsera.Blazor.Toaster.Core.Models;
using Codeer.LowCode.Blazor.Components.AppParts.Loading;
using Codeer.LowCode.Blazor.Extras.Approval;
using Codeer.LowCode.Blazor.Extras.Fields;
using Codeer.LowCode.Blazor.Extras.Mail;
using Codeer.LowCode.Blazor.Extras.ScriptObjects;
using Codeer.LowCode.Blazor.Extras.Services;
using Microsoft.Extensions.DependencyInjection;
using System.Globalization;

namespace $safeprojectname$.Services
{
    public static class ServiceInitializer
    {
        public static void AddSharedServices(this IServiceCollection services)
        {
            //Extras の組み込みサービスが使うエンドポイント
            MailTransport.SendMailEndPoint = "/api/mail";
            MailTransport.BulkSearchMailEndPoint = "/api/mail/bulk_search";
            MailTransport.PreviewMailEndPoint = "/api/mail/preview";
            MailTransport.BulkPreviewMailEndPoint = "/api/mail/bulk_preview";
            ApprovalTransport.EndPointBase = "/api/approval";
            Codeer.LowCode.Blazor.Extras.ScriptObjects.Excel.ConvertPdfEndPoint = "api/excel/pdf";
            AITextAnalyzerField.FileToModuleDataEndPoint = "/api/ai_text_analyze/file";
            //認証アプリ (TOTP) 解除ボタン (MyTotpResetButtonField)
            TotpResetClient.StatusEndPoint = "/api/account/totp/status";
            TotpResetClient.ResetEndPoint = "/api/account/totp/reset";
            AITextAnalyzerField.TextToModuleDataEndPoint = "/api/ai_text_analyze/text";
            AIChatField.EndPoint = "/api/ai_chat";
            SemanticSearchField.EndPoint = "/api/semantic_search/reindex";
            BulkFileReader.ParseFileEndPoint = "/api/module_data/parse_file";
            BulkFileTransferService.ListFileByDataEndPoint = "/api/module_data/list_file_by_data";
            BulkFileTransferService.BulkSubmitEndPoint = "/api/module_data/bulk_submit";

            services.AddScoped<IAppInfoService, AppInfoService>();
            services.AddScoped<IModuleDataService, ModuleDataService>();
            services.AddScoped<IUIService, UIService>();
            services.AddScoped<Codeer.LowCode.Blazor.RequestInterfaces.Services>();
            services.AddScoped<ILogger, Logger>();
            services.AddSingleton<LoadingService>();
            services.AddToaster(config =>
            {
                config.PositionClass = Defaults.Classes.Position.BottomRight;
                config.MaximumOpacity = 100;
                config.VisibleStateDuration = 1000 * 5;
                config.ShowTransitionDuration = 10;
                config.HideTransitionDuration = 500;
            });
            services.AddScoped<IToastService, ToastService>();
            services.AddScoped<IHttpService, HttpService>();

            var cultureName = CultureInfo.CurrentCulture.Name;
            if (cultureName == "ja") cultureName = "ja-JP";
            var cultureInfo = new CultureInfo(cultureName);
            CultureInfo.DefaultThreadCurrentCulture = cultureInfo;
            CultureInfo.DefaultThreadCurrentUICulture = cultureInfo;
        }
    }
}
